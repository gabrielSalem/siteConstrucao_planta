<ul class="nav navbar-collapse" style="background: rgb(41,59,98);"> 
	<li class="nav-item text-center">
		<a class="nav-link font-weight-bold text-white py-3" href="painel.php"><img src="../imagem/icon.png" width="48px" class="custom-radio my-1rounded-right"><br><i class="fa fa-users"></i> (<?php echo $usuario;?>)</a>
	</li>
	<li class="nav-item">
		<a class="nav-link font-weight-bold text-white p-4" href="../painel.php"><h5><i class="fa fa-home"></i> Projetos-store</h5></a>
	</li>
	<li class="nav-item float-right">
		<a class="nav-link text-light py-4" href="../req/logout.php"><i class="fa fa-user"></i> Sair</a>
	</li>
</ul>