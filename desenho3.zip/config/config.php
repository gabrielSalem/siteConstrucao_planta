<?php
define("SERVIDOR","localhost");
define("USUARIO", "root");
define("SENHA", "");
define("BANCO", "desenho");
define("CHARSET","utf8");
